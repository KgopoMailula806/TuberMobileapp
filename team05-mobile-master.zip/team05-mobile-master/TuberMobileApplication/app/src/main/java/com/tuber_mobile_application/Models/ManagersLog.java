package com.tuber_mobile_application.Models;

public class ManagersLog {
}
