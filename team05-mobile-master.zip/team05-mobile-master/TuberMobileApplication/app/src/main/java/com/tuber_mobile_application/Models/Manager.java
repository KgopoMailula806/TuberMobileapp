package com.tuber_mobile_application.Models;

public class Manager {

    private int id;
    private int cvid;
    private int user_Table_Reference;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCvid() {
        return cvid;
    }

    public void setCvid(int cvid) {
        this.cvid = cvid;
    }

    public int getUser_Table_Reference() {
        return user_Table_Reference;
    }

    public void setUser_Table_Reference(int user_Table_Reference) {
        this.user_Table_Reference = user_Table_Reference;
    }
}
